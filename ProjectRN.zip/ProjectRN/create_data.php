<?php

// read in the details of our MySQL server:
require_once "credentials.php";

// We'll use the procedural (rather than object oriented) mysqli calls

// connect to the host:
$connection = mysqli_connect($dbhost, $dbuser, $dbpass);

// exit the script with a useful message if there was an error:
if (!$connection)
{
    die("Connection failed: " . $mysqli_connect_error);
}
  
// build a statement to create a new database:
$sql = "CREATE DATABASE IF NOT EXISTS " . $dbname;

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Database created successfully, or already exists<br>";
} 
else
{
    die("Error creating database: " . mysqli_error($connection));
}

// connect to our database:
mysqli_select_db($connection, $dbname);

///////////////////////////////////////////
////////////// MEMBERS TABLE //////////////
///////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS members";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Dropped existing table: members<br>";
} 
else 
{   
    die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE members (username VARCHAR(16), password VARCHAR(16), type INT DEFAULT 0,muted INT DEFAULT 0, highscore INT DEFAULT 0, PRIMARY KEY(username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Table created successfully: members<br>";
}
else 
{
    die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames[] = 'jjermain'; $passwords[] = 'admin'; $type[]=1;
$usernames[] = 'kkarl'; $passwords[] = 'access'; $type[]=0;
$usernames[] = 'ffaizan'; $passwords[] = 'access1'; $type[]=0;
$usernames[] = 'ggkidd'; $passwords[] = 'access2'; $type[]=0;


// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
    $sql = "INSERT INTO members (username, password, type) VALUES ('$usernames[$i]', '$passwords[$i]','$type[$i]')";
    
    // no data returned, we just test for true(success)/false(failure):
    if (mysqli_query($connection, $sql)) 
    {
        echo "row inserted<br>";
    }
    else 
    {
        die("Error inserting row: " . mysqli_error($connection));
    }
}
//////////////////////////////////////////////
////////////// FAVOURITES TABLE //////////////
//////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS chat";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
    //drops the existed table in the favourites area
    echo "Dropped existing table: chat<br>";
} 
else 
{   
    die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE chat (username VARCHAR(16), text VARCHAR(140), updated DATETIME, likes INT DEFAULT 0, PRIMARY KEY(username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Table created successfully: chat<br>";
}
else 
{
    die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'jjermain'; $text[] = 77; $updates[] = '2016-02-15 16:23:12';
$usernames[] = 'kkarl'; $text[] = 888; $updates[] = '2016-11-05 07:13:52';
$usernames[] = 'ffaizan'; $text[] = 66; $updates[] = '2016-07-23 11:32:21';
$usernames[] = 'ggkidd'; $text[] = 50; $updates[] = '2016-11-04 10:10:05';


// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
    $sql = "INSERT INTO chat (username, text, updated ) VALUES ('$usernames[$i]', $text[$i], '$updates[$i]')";
    
    // no data returned, we just test for true(success)/false(failure):
    if (mysqli_query($connection, $sql)) 
    {
        echo "row inserted<br>";
    }
    else 
    {
        die("Error inserting row: " . mysqli_error($connection));
    }
}
//////////////////////////////////////////////
////////////// FAVOURITES TABLE //////////////
//////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS favourites";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
    echo "Dropped existing table: favourites<br>";
} 
else 
{   
    die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE favourites (username VARCHAR(16), value BIGINT, updated DATETIME, likes INT DEFAULT 0, PRIMARY KEY(username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Table created successfully: favourites<br>";
}
else 
{
    die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'jjermain'; $values[] = 77; $updates[] = '2016-02-15 16:23:12';
$usernames[] = 'kkarl'; $values[] = 888; $updates[] = '2016-11-05 07:13:52';
$usernames[] = 'ffaizan'; $values[] = 66; $updates[] = '2016-07-23 11:32:21';
$usernames[] = 'ggkidd'; $values[] = 50; $updates[] = '2016-11-04 10:10:05';


// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
    $sql = "INSERT INTO favourites (username, value, updated) VALUES ('$usernames[$i]', $values[$i], '$updates[$i]')";
    
    // no data returned, we just test for true(success)/false(failure):
    if (mysqli_query($connection, $sql)) 
    {
        echo "row inserted<br>";
    }
    else 
    {
        die("Error inserting row: " . mysqli_error($connection));
    }
}

////////////////////////////////////////////
////////////// PROFILES TABLE //////////////
////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS profiles";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
    echo "Dropped existing table: profiles<br>";
} 
else 
{   
    die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = "CREATE TABLE profiles (username VARCHAR(16), firstname VARCHAR(40), lastname VARCHAR(50), age TINYINT, email VARCHAR(50), dob DATE, PRIMARY KEY (username))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Table created successfully: profiles<br>";
}
else 
{
    die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
//$usernames[] = 'barryg'; $firstnames[] = 'Barry'; $lastnames[] = 'Grimes'; $ages[] = 55; $emails[] = 'baz_g@outlook.com'; $dobs[] = '1961-09-25';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
    $sql = "INSERT INTO profiles (username, firstname, lastname,  age, email, dob) VALUES ('$usernames[$i]', '$firstnames[$i]', '$lastnames[$i]', '$ages[$i], '$emails[$i]', '$dobs[$i]')";
    
    // no data returned, we just test for true(success)/false(failure):
    if (mysqli_query($connection, $sql)) 
    {
        echo "row inserted<br>";
    }
    else 
    {
        die("Error inserting row: " . mysqli_error($connection));
    }
}
////////////////////////////////////////////
////////////// Chat TABLE //////////////
////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS chat";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
    echo "Dropped existing table: chat<br>";
} 
else 
{   
    die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = $sql = "CREATE TABLE chat (post_id SERIAL, username VARCHAR(16), chats VARCHAR(140), updated TIMESTAMP, likes INT DEFAULT 0, PRIMARY KEY(post_id))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Table created successfully: chat<br>";
}
else 
{
    die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
$usernames = array(); // clear this array (as we already used it above)
$usernames[] = 'jjermain'; $chats[] = 'ggfdgfdgfdgfd'; $updates[] = '2016-02-15 16:23:12';
$usernames[] = 'kkarl';  $chats[] = '4erwreerwqerwerer'; $updates[] = '2016-11-05 07:13:52';
$usernames[] = 'ffaizan'; $chats[] =  'vcvccbvcbvbvc'; $updates[] = '2016-07-23 11:32:21';
$usernames[] = 'ggkidd';  $chats[] =  'jjjjjjj'; $updates[] = '2016-11-04 10:10:05';

// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
$sql = "INSERT INTO chat ( username, chats, updated) VALUES ('$usernames[$i]', '$chats[$i]', '$updates[$i]')";
    
    // no data returned, we just test for true(success)/false(failure):
    if (mysqli_query($connection, $sql)) 
    {
        echo "row inserted<br>";
    }
    else 
    {
        die("Error inserting row: " . mysqli_error($connection));
    }
}

////////////////////////////////////////////
////////////// score TABLE //////////////
////////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS score";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql))
{
    echo "Dropped existing table: score<br>";
} 
else 
{   
    die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
$sql = $sql = "CREATE TABLE score (post_id SERIAL, username VARCHAR(16), score INT , PRIMARY KEY(post_id))";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
    echo "Table created successfully: score<br>";
}
else 
{
    die("Error creating table: " . mysqli_error($connection));
}

// we're finished, close the connection:
mysqli_close($connection);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>