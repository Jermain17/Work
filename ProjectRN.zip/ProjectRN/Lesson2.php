<?php

// execute the header script:
require_once "header.php";
$chats = ""; 

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 20;

if (!isset($_SESSION['loggedInWeek12']))
{
    
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{
    
    // has the form just been submitted? Or have we arrived here by using the navigation bar?

// the session starts   
$username = $_SESSION['username'];
if(ISSET($_POST['chats']))
{
$message = $_POST['chats'];
    // user is already logged in, read all the favourite numbers and display in a table:
    
    // connect directly to our database (notice 4th argument):
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
    
    // find all favourite numbers, ordered by their last update time (descending):
    $query = "INSERT INTO chat(username, chats ) VALUES ('$username', '$message') ";    
    // this query can return data ($result is an identifier):
    $result = mysqli_query($connection, $query);
            
    // how many rows came back?:
    //$n = mysqli_num_rows($result);
        if (! $result){
            echo mysqli_error($connection);
        }
}
    // if we got some results then show them in a table:

    {
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END

<title>HTML</title>
</head>
<body>
<div class="cwrapper">
<div class="container">

    <div class="cheader">
        <h1 class="ctitle"><i class="fa fa-pencil" aria-hidden="true"></i> HTML</h1>
        <p class="lead cdescription">Lesson 2</p>
    </div>

    <div class="row">

        <div class="col-sm-8 blog-main">

            <div class="cpost">
                <h2 class="cpost-title"><i class="fa fa-cogs" aria-hidden="true"></i> HTML Basic Examples</h2>
                <p class="cpost-meta">February 2, 2017 by <a href="#">Jermain Johnson</a></p>
				<li><a href="quiz2.html">Quiz</a></li>
                <hr>
                <p class="lead cdescription"><i class="fa fa-align-center" aria-hidden="true"></i> What is HTML? </p>
                <ul id="markdown-toc">
                    <li><strong>HTML headings are used with the h1 to h6 tags. h1 defines the importants heading, 
					h6 defines the least important heading.</strong></li>
                    <li><strong>HTML paragraph are defined with the p tag.</strong></li>
                    <li><strong>HTML HTML links are defined with a tag.</strong></li>
                    <li><strong>Imagines in HTML are defined with img tag, with the src(source file), with the alternative alt. Also with the width and height as attributes.</strong></li>
                </ul>
                <hr>
                <p class="lead cdescription"><i class="fa fa-align-center" aria-hidden="true"></i>Simple HTML Document</p>

				<pre><code>
				<h3>Example Code</h3>
				<!DOCTYPE html>
<div class="code notranslate htmlHigh">
 &lt;!DOCTYPE html&gt;<br>
&lt;html&gt;<br>&lt;head&gt;<br>&lt;title&gt;Page Title&lt;/title&gt;<br>
 &lt;/head&gt;<br>
&lt;body&gt;<br><br>&lt;h1&gt;My First Heading&lt;/h1&gt;<br>
&lt;p&gt;My first paragraph.&lt;/p&gt;<br><br>
&lt;body&gt;<br><br>&lt;h2&gt;My Second Heading&lt;/h2&gt;<br>
&lt;p&gt;My second paragraph.&lt;/p&gt;<br><br>
&lt;body&gt;<br><br>&lt;h3&gt;My Third Heading&lt;/h3&gt;<br>
&lt;p&gt;My third paragraph.&lt;/p&gt;<br><br>
    &lt;/body&gt;<br>&lt;/html&gt;
</div>

<h3>Example</h3>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<h1>My First Heading</h1>
<h2>My Second Heading</h2>
<h3>My Third Heading</h3>
<p>My first paragraph.</p>
<p>My second paragraph.</p>
<p>My third paragraph.</p>

</body>
</html></pre></code>
            </div>

			
            <nav>
                <ul class="pager">
                    <li><a href="Lesson3.php">Next</a></li>
					<li><a href="Lesson1.php">Previous</a></li>
                </ul>
            </nav>
        
    </div>
</div>
</div>
_END;

}
}


// finish off the HTML for this page:
require_once "footer.php";
?>
