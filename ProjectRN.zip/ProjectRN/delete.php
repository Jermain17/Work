<?php


// execute the header script:
require_once "header.php";
$chats = ""; 
$post_id = ""; 

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 20;

$username = "";
if(isset($_POST['username']))
	$username = $_POST['username'];

if (!isset($_SESSION['loggedInWeek12']))
{
	
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{
	
	// has the form just been submitted? Or have we arrived here by using the navigation bar?
	// if(!isset($_POST['chats']))
	
$username = $_SESSION['username'];
if(isset($_POST['chats']))
{
$message = $_POST['chats'];
	// user is already logged in, read all the favourite numbers and display in a table:
	
	// connect directly to our database (notice 4th argument):
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	$query = "SELECT * FROM chat"; //selects everyone from chat because it has the *
	// find all favourite numbers, ordered by their last update time (descending):
	$query1 = "DELETE FROM chat WHERE  post_id = 'username'";	
	// this query can return data ($result is an identifier):
	$result = mysqli_query($connection, $query);
	
	$result1 = mysqli_query($connection, $query1);
			
	// how many rows came back?:
	$n = mysqli_num_rows($result);
		if (! $result){
			echo mysqli_error($connection);
		}
}
	// if we got some results then show them in a table:

	{
// CSS to make the table clearly visible, and jQuery to control updates:
//This php part underneath does all the work, like when the table id says chat. It will get the users from the table on my phpadmin.

echo <<<_END
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	
<style>
	table, th, td {border: 1px solid black; align: center;}
</style>
<table id='chat'> 
<tr><th>User</th><th>chat</th><th>Updated</th><th>Likes</th><th></th></tr>
</table>

<script>
$(document).ready(function()
{	
	// as soon as the page is ready, start checking for updates:
	checkForFavourites();
});

function checkForFavourites(){
		
    $.getJSON('api/recent.php', {number: $nrows})
		.done(function(data) {
			// debug message to help during development:
			console.log('request successful');
			
			// remove the old table rows:
			$('.result').remove();
			
			// loop through what we got and add it to the table (data is already a JavaScript object thanks to getJSON()):
			$.each(data, function(index, value) {
				$('#chat').append("<tr class='result'><td>" + value.post_id + "</td><td>" + value.username + "</td><td>" + value.chats + "</td><td>" + value.updated + "</td><td>" + value.likes + "</td></tr>");
			});
		})
		.fail(function(jqXHR) {
			// debug message to help during development:
			console.log('request returned failure, HTTP status code ' + jqXHR.status);
		})
		.always(function() {
			// debug message to help during development:
			console.log('request completed');
			// call this function again after a brief pause:
			setTimeout(checkForFavourites, $milliseconds);
		});
}

</script>

<form action="Delete.php" method="post">
Delete A Comment:<br>
Message: <input type="number" name="username" value="$post_id">
<input type="submit" value="Submit">
</form>
_END;
}
}

// finish off the HTML for this page:
require_once "footer.php";
?>