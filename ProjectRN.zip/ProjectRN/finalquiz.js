
function check(){

	var question1 = document.quiz.question1.value;
	var question2 = document.quiz.question2.value;
	var question3 = document.quiz.question3.value;
	var question4 = document.quiz.question4.value;
	var question5 = document.quiz.question5.value;
	var question6 = document.quiz.question6.value;
	var question7 = document.quiz.question7.value;
	var question8 = document.quiz.question8.value;
	var question9 = document.quiz.question9.value;
	var question10 = document.quiz.question10.value;
	var question11 = document.quiz.question11.value;
	var question12 = document.quiz.question12.value;
	var question13 = document.quiz.question13.value;
	var question14 = document.quiz.question14.value;
	var question15 = document.quiz.question15.value;


	
	var correct = 0;


if (question1 == "Hyper Text Markup Language") {
	correct++;	
}
if (question2 == "Heading") {
	correct++;	
}
if (question3 == "br") {
	correct++;	
}
if (question4 == "2") {
	correct++;	
}
if (question5 == "Closing tag has a / in front") {
	correct++;	
}
if (question6 == "Opening") {
	correct++;	
}
if (question7 == "Closing") {
	correct++;	
}
if (question8 == "Empty element") {
	correct++;	
}
if (question9 == "< img / >") {
	correct++;	
}
if (question10 == "Quotation marks") {
	correct++;	
}
if (question11 == "In the same folder") {
	correct++;	
}
if (question12 == "slider") {
	correct++;	
}
if (question13 == "Brings up a note pad with the HTML code already used for the site") {
	correct++;	
}
if (question14 == "True") {
	correct++;	
}
if (question15 == "/") {
	correct++;	
}




	document.getElementById("after_submit").style.visibility = "visible";
	document.getElementById("number_correct").innerHTML = "You got " + correct + " correct.";

	}
	
