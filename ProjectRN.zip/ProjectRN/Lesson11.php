<?php

// execute the header script:
require_once "header.php";
$chats = ""; 

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 20;

if (!isset($_SESSION['loggedInWeek12']))
{
    
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{
    
    // has the form just been submitted? Or have we arrived here by using the navigation bar?

// the session starts   
$username = $_SESSION['username'];
if(ISSET($_POST['chats']))
{
$message = $_POST['chats'];
    // user is already logged in, read all the favourite numbers and display in a table:
    
    // connect directly to our database (notice 4th argument):
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
    
    // find all favourite numbers, ordered by their last update time (descending):
    $query = "INSERT INTO chat(username, chats ) VALUES ('$username', '$message') ";    
    // this query can return data ($result is an identifier):
    $result = mysqli_query($connection, $query);
            
    // how many rows came back?:
    //$n = mysqli_num_rows($result);
        if (! $result){
            echo mysqli_error($connection);
        }
}
    // if we got some results then show them in a table:

    {
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END

<title>HTML</title>
</head>
<body>
<div class="cwrapper">
<div class="container">

    <div class="cheader">
        <h1 class="ctitle"><i class="fa fa-pencil" aria-hidden="true"></i> HTML</h1>
        <p class="lead cdescription">Lesson 11</p>
    </div>

    <div class="row">

        <div class="col-sm-8 blog-main">

            <div class="cpost">
                <h2 class="cpost-title"><i class="fa fa-cogs" aria-hidden="true"></i> HTML Tables</h2>
                <p class="cpost-meta">February 2, 2017 by <a href="#">Jermain Johnson</a></p>
				<li><a href="quiz11.html">Quiz</a></li>
                <hr>
                <p class="lead cdescription"><i class="fa fa-align-center" aria-hidden="true"></i> HTML </p>
                <ul id="markdown-toc">
                    <li><strong>HTML table defined with a table tag.</strong></li>
                    <li><strong>Each table row are defined with a tr tag.</strong></li>
            
					
			
                </ul>
                <hr>
                <p class="lead cdescription"><i class="fa fa-align-center" aria-hidden="true"></i>Simple HTML Document</p>

				<pre><code>
				<h3>Example Code</h3>
<div class="code notranslate htmlHigh">
&lt;table style=&quot;width:100%&quot;&gt;<br>&nbsp;
&lt;tr&gt;<br>&nbsp;&nbsp;&nbsp; &lt;th&gt;Firstname&lt;/th&gt;<br>
&nbsp;&nbsp;&nbsp; &lt;th&gt;Lastname&lt;/th&gt; <br>&nbsp;&nbsp;&nbsp; &lt;th&gt;Age&lt;/th&gt;<br>
&nbsp;
&lt;/tr&gt;<br>&nbsp;
&lt;tr&gt;<br>&nbsp; &nbsp; &lt;td&gt;Monkey D&lt;/td&gt;<br>
&nbsp;&nbsp;&nbsp; &lt;td&gt;Luffy&lt;/td&gt; <br>&nbsp;&nbsp;&nbsp; &lt;td&gt;20&lt;/td&gt;<br>
&nbsp;
&lt;/tr&gt;<br>&nbsp; &lt;tr&gt;<br>&nbsp;&nbsp;&nbsp; &lt;td&gt;Marco D&lt;/td&gt;<br>
&nbsp;&nbsp;&nbsp; &lt;td&gt;Phoenix&lt;/td&gt; <br>&nbsp;&nbsp;&nbsp; &lt;td&gt;25&lt;/td&gt;<br>

&lt;/tr&gt;<br>&nbsp; &lt;tr&gt;<br>&nbsp;&nbsp;&nbsp; &lt;td&gt;Monkey D D&lt;/td&gt;<br>
&nbsp;&nbsp;&nbsp; &lt;td&gt;Dragon&lt;/td&gt; <br>&nbsp;&nbsp;&nbsp; &lt;td&gt;40&lt;/td&gt;<br>
&nbsp; &lt;/tr&gt;<br>&lt;/table&gt;


<table style="width:100%">
  <tr>
    <th>Firstname</th>
    <th>Lastname</th> 
    <th>Age</th>
  </tr>
  <tr>
    <td>Monkey D </td>
    <td>Luffy</td>
    <td>20</td>
  </tr>
  <tr>
    <td>Marco D </td>
    <td>Phoenix</td>
    <td>25</td>
  </tr>
  <tr>
    <td>Monkey D</td>
    <td>Dragon</td>
    <td>40</td>
  </tr>
</table>



</div>
<h3>Example</h3>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<table style="width:100%">
  <tr>
    <th>Firstname</th>
    <th>Lastname</th> 
    <th>Age</th>
  </tr>
  <tr>
    <td>Monkey D </td>
    <td>Luffy</td>
    <td>20</td>
  </tr>
  <tr>
    <td>Marco D </td>
    <td>Phoenix</td>
    <td>25</td>
  </tr>
  <tr>
    <td>Monkey D</td>
    <td>Dragon</td>
    <td>40</td>
  </tr>
</table>

</body>
</html>



</body>
</html></pre></code>
                   
            <nav>
                <ul class="pager">
                    <li><a href="Lesson12.php">Next</a></li>
					 <li><a href="Lesson10.php">Previous</a></li>
                </ul>
            </nav>
        
    </div>
</div>
</div>
_END;

}
}


// finish off the HTML for this page:
require_once "footer.php";
?>
