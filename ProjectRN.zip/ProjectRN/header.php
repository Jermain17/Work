<?php


// database connection details:
require_once "credentials.php";

// our helper functions:
require_once "helper.php";

// start/restart the session:
session_start(); //Sessions details stored in the server

if (isset($_SESSION['loggedInWeek12']))
{
    // THIS PERSON IS LOGGED IN
    // show the logged in menu options:
    $username = $_SESSION["username"];
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    $query = "SELECT * FROM members where username ='$username'"; //this is the query that selects all the people that are in my members table
    
    $result = mysqli_query($connection, $query);
    $row= mysqli_fetch_assoc($result);
    $type = $row['type'];
    
    if ($type==1)
    {
        echo <<<_END
<body>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>



<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
  <a class="navbar-" href="home.php">
  </a>
       <li class="active"><a href="home.php">Home <span class="sr-only">(current)</span></a></li> 
        <li><a href="chat3.php">Chat</a></li>
		<li><a href="search.php">Search</a></li>
		<li><a href="admin.php">admin</a></li>
        <li class="dropdown">

          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Learn HTML <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="Lesson1.php">Lesson 1</a></li>
			<li><a href="Lesson2.php">Lesson 2</a></li>
            <li><a href="Lesson3.php">Lesson 3</a></li>
            <li><a href="Lesson4.php">Lesson 4</a></li>
			<li><a href="Lesson5.php">Lesson 5</a></li>
            <li><a href="Lesson6.php">Lesson 6</a></li>
			 <li><a href="Lesson7.php">Lesson 7</a></li>
			<li><a href="Lesson8.php">Lesson 8</a></li>
            <li><a href="Lesson9.php">Lesson 9</a></li>
             <li><a href="Lesson10.php">Lesson 10</a></li>
			<li><a href="Lesson11.php">Lesson 11</a></li>
            <li><a href="Lesson12.php">Lesson 12</a></li>
			<li><a href="Lesson13.php">Lesson 13</a></li>
			<li><a href="Lesson14.php">Lesson 14</a></li>
            <li><a href="Lesson15.php">Lesson 15</a></li>
          </ul>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="sign_out.php">Sign Out</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</body>
</html>


_END;
    }
    else {

echo <<<_END
<body>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<style>
@media (min-width: 768px) {
  .navbar-nav.navbar-center {
    position: absolute;
    left: 50%;
    transform: translatex(-50%);
  }
}
</style>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
	
	 <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
       <a class="navbar-" href="home.php">
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
        <ul class="nav navbar-nav">
  <a class="navbar-brand" href="home.php">
  </a>
       <li class="active"><a href="home.php">Home <span class="sr-only">(current)</span></a></li> 
		 <li><a href="chat3.php">Chat</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Learn HTML <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="Lesson1.php">Lesson 1</a></li>
			<li><a href="Lesson2.php">Lesson 2</a></li>
            <li><a href="Lesson3.php">Lesson 3</a></li>
            <li><a href="Lesson4.php">Lesson 4</a></li>
			<li><a href="Lesson5.php">Lesson 5</a></li>
            <li><a href="Lesson6.php">Lesson 6</a></li>
			 <li><a href="Lesson7.php">Lesson 7</a></li>
			<li><a href="Lesson8.php">Lesson 8</a></li>
            <li><a href="Lesson9.php">Lesson 9</a></li>
             <li><a href="Lesson10.php">Lesson 10</a></li>
			<li><a href="Lesson11.php">Lesson 11</a></li>
            <li><a href="Lesson12.php">Lesson 12</a></li>
			<li><a href="Lesson13.php">Lesson 13</a></li>
			<li><a href="Lesson14.php">Lesson 14</a></li>
            <li><a href="Lesson15.php">Lesson 15</a></li>
          </ul>
        </li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="sign_out.php">Sign Out</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
</body>
</html>


_END;
    }
}

else
{
    // THIS PERSON IS NOT LOGGED IN
    // show the logged out menu options:
    
echo <<<_END
<!DOCTYPE html>
<html>
<body>
<a href='about.php'>about</a> ||
<a href='sign_up.php'>sign up</a> ||
<a href='sign_in.php'>sign in</a> ||
<a href='forgotpassword.php'>forgot password</a> ||
<br><br>
_END;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>