<?php

// execute the header script:
require_once "header.php";
$chats = ""; 

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 20;

if (!isset($_SESSION['loggedInWeek12']))
{
    
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{
    
    // has the form just been submitted? Or have we arrived here by using the navigation bar?

// the session starts   
$username = $_SESSION['username'];
if(ISSET($_POST['chats']))
{
$message = $_POST['chats'];
    // user is already logged in, read all the favourite numbers and display in a table:
    
    // connect directly to our database (notice 4th argument):
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
    
    // find all favourite numbers, ordered by their last update time (descending):
    $query = "INSERT INTO chat(username, chats ) VALUES ('$username', '$message') ";    
    // this query can return data ($result is an identifier):
    $result = mysqli_query($connection, $query);
            
    // how many rows came back?:
    //$n = mysqli_num_rows($result);
        if (! $result){
            echo mysqli_error($connection);
        }
}
    // if we got some results then show them in a table:

    {
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END

<title>HTML</title>
</head>
<body>
<div class="cwrapper">
<div class="container">

    <div class="cheader">
        <h1 class="ctitle"><i class="fa fa-pencil" aria-hidden="true"></i> HTML</h1>
        <p class="lead cdescription">Lesson 7</p>
    </div>

    <div class="row">

        <div class="col-sm-8 blog-main">

            <div class="cpost">
                <h2 class="cpost-title"><i class="fa fa-cogs" aria-hidden="true"></i> HTML Comments</h2>
                  <h2 class="cpost-title"><i class="fa fa-cogs" aria-hidden="true"></i></h2>
                <p class="cpost-meta">February 2, 2017 by <a href="#">Jermain Johnson</a></p>
				<li><a href="quiz.html">Quiz</a></li>
                <hr>
                <p class="lead cdescription"><i class="fa fa-align-center" aria-hidden="true"></i> HTML Comments </p>
                <ul id="markdown-toc">
                    <li><strong>Comments are also great for debugging HTML, because you can comment out HTML lines of code, one at a time, to search for errors.</strong></li>
 

                </ul>
                <hr>
                <p class="lead cdescription"><i class="fa fa-align-center" aria-hidden="true"></i>Simple HTML Document</p>

				<pre><code>
				<h3>Example Code</h3>
<div class="code notranslate htmlHigh">
&lt;!-- Write your comments here --&gt;
&lt;p&gt;This is a paragraph&lt;/p&gt;<br>
&lt;!-- Remember to add more information here --&gt;

</body>
</html></pre></code>
                   
            <nav>
                <ul class="pager">
                    <li><a href="Lesson8.php">Next</a></li>
					 <li><a href="Lesson6.php">Previous</a></li>
                </ul>
            </nav>
        
    </div>
</div>
</div>
_END;

}
}


// finish off the HTML for this page:
require_once "footer.php";
?>
