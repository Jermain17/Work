<?php


// execute the header script:
require_once "header.php";

$username = "";
if (isset ($_POST['username']))
{
	$username = $_POST['username'];
}
if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{
	// user is already logged in, read all the favourite numbers and display in a table:
	
	// connect directly to our database (notice 4th argument):
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	// find all favourite numbers, ordered by their last update time (descending):
	$query = "SELECT * FROM members "; //this is the query that selects all the people that are in my members table
	$query2 = "SELECT username, chats FROM chat WHERE username = '$username'"; //selects all the username from chats
	$query3 = "SELECT * FROM profiles WHERE username = '$username '"; //selects all the people from my profile
	$query4 = "SELECT * FROM profiles WHERE username='$username'"; //selects all the people from profiles
	// this query can return data ($result is an identifier):
	
	$result = mysqli_query($connection, $query);
			
	// how many rows came back?:
	$n = mysqli_num_rows($result);
	
	$result2 = mysqli_query($connection, $query2);
			
	// how many rows came back?:
	$n2 = mysqli_num_rows($result2);
	
	// this query can return data ($result is an identifier):
	$result4 = mysqli_query($connection, $query4);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
	$n4 = mysqli_num_rows($result4);
		

	
		
	// if we got some results then show them in a table:
	if ($n > 0)
	{
		// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	
<style>
	table, th, td {border: 1px solid black; align: center;}
</style>



_END;
		echo "<table id='members'>";
		echo "<tr><th>User</th></tr>";
		// loop over all rows, adding them into the table:
		for ($i=0; $i<$n; $i++)
		{
			// fetch one row as an associative array (elements named after columns):
			$row = mysqli_fetch_assoc($result);
			
			// read the values out here to keep the HTML below more readable:
			$username = $row['username'];
			
			// add it as a row in our table:
			echo "<tr id='$username'>";
			echo "<td>$username</td>";
			echo "</tr>";
		}
		echo "</table>";
	}
	else
	{
		// no favourites found...:
		echo "no favourite numbers found<br>";
	}
	
		if ($n2 > 0)
	{
		// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>	
	
<style>
	table, th, td {border: 1px solid black; align: center;}
</style>



_END;
if (isset ($_POST['username']))
	{
		echo "<table id='members'>";
		echo "<tr><th>User</th></tr>";
		// loop over all rows, adding them into the table:
		for ($i=0; $i<$n; $i++)
		{
			// fetch one row as an associative array (elements named after columns):
			$row = mysqli_fetch_assoc($result2);
			
			// read the values out here to keep the HTML below more readable:
			$username = $row['username'];
			$chats = $row['chats'];
			
			// add it as a row in our table:
			echo "<tr id='$username'>";
			echo "<td>$username</td>";
			echo "<td>$chats</td>";
			echo "</tr>";
		}
		echo "</table>";
	}
	else
	{
		// no favourites found...:
		echo "this user hasn't posted found<br>";
	}
	
	}
	
// check for a row in our profiles table with a matching username:
	
	if (isset ($_POST['username']))
	{
		
	// if there was a match then extract their profile data:
	if ($n4 > 0)
	{
		// use the identifier to fetch one row as an associative array (elements named after columns):
		$row4 = mysqli_fetch_assoc($result4);
		// display their profile data:
		echo "First name: {$row4['firstname']}<br>";
		echo "Last name: {$row4['lastname']}<br>";
		echo "Age: {$row4['age']}<br>";
		echo "Email address: {$row4['email']}<br>";
		echo "Date of birth: {$row4['dob']}<br>";
	}
	else
	{
		// no match found, prompt user to set up their profile:
		echo "This user still needs to set up a profile!<br>";
	}
	}
	// we're finished with the database, close the connection:
	mysqli_close($connection);
}
?>
<form action = "search.php" method = "POST">
Search User <br>
<p>Users: <input type="text" name="username" value="<?php if(isset($_POST['username'])) echo $_POST['username'];?>" /></p>
<br>
<p><input type="submit" value="Submit" name="submit" id="username"></p>
</form> 
<?php
// finish off the HTML for this page:
require_once "footer.php";

?>