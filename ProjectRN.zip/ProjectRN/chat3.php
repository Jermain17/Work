<?php

// execute the header script:
require_once "header.php";
$chats = ""; 

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 20;

if (!isset($_SESSION['loggedInWeek12']))
{
    
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{
    
    // has the form just been submitted? Or have we arrived here by using the navigation bar?

// the session starts   
$username = $_SESSION['username'];
if(ISSET($_POST['chats']))
{
$message = $_POST['chats'];
    // user is already logged in, read all the favourite numbers and display in a table:
    
    // connect directly to our database (notice 4th argument):
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
    
    // find all favourite numbers, ordered by their last update time (descending):
    $query = "INSERT INTO chat(username, chats ) VALUES ('$username', '$message') ";    
    // this query can return data ($result is an identifier):
    $result = mysqli_query($connection, $query);
            
    // how many rows came back?:
    //$n = mysqli_num_rows($result);
        if (! $result){
            echo mysqli_error($connection);
        }
}
    // if we got some results then show them in a table:

    {
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>   
    
<style>
    table, th, td {border: 1px solid black; align: center;}
</style>
<table id='chat'>
<tr><th>User</th><th>chat</th><th>Updated</th><th>Likes</th>><th></th></tr>
</table>

<script>
$(document).ready(function()
{
    $(document).on("click", "#chat a",function() {
       
    event.preventDefault();
            console.log("bf");
                
        // make a javascript object to hold our request data:
        var request = {};
        request["post_id"] = $(this).data('post_id');

        
        $.post('api/like.php',request)
        .done(function(data) {
            // debug message to help during development:
            console.log('request successful')
            
            // update the relevant user's likes number by one:
            var currentLikes = parseInt($('#' + data.post_id + ' .like').text(),10);
            var newLikes = currentLikes + 1;
            $('#' + data.post_id + ' .like').text(newLikes);
                
        })
        .fail(function(jqXHR) {
            // debug message to help during development:
            console.log('request returned failure, HTTP status code ' + jqXHR.status);
        })
        .always(function() {
            // debug message to help during development:
            console.log('request completed');
        });
    
    });
    checkForFavourites();
});

function checkForFavourites(){
        
    $.getJSON('api/recent.php', {number: $nrows})
        .done(function(data) {
            // debug message to help during development:
            console.log('request successful');
            
            // remove the old table rows:
            $('.result').remove();
            
            // loop through what we got and add it to the table (data is already a JavaScript object thanks to getJSON()):
            $.each(data, function(index, value) {
                $('#chat').append("<tr class='result'><td>" + value.username + "</td><td>" + value.chats + "</td><td>" + value.updated + "</td><td>" + value.likes + "</td><td>"+ "<a data-post_id='"+value.post_id +"'>+</a></td></tr>");
            });
        })
        .fail(function(jqXHR) {
            // debug message to help during development:
            console.log('request returned failure, HTTP status code ' + jqXHR.status);
        })
        .always(function() {
            // debug message to help during development:
            console.log('request completed');
            // call this function again after a brief pause:
            setTimeout(checkForFavourites, $milliseconds);
        });
}

</script>
_END;


    // THIS PERSON IS LOGGED IN
    // show the logged in menu options:
    $username = $_SESSION["username"];
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    $query = "SELECT * FROM members where username ='$username'"; //selects everyone from my members table
    
    $result = mysqli_query($connection, $query);
    $row= mysqli_fetch_assoc($result);
    $muted = $row['muted'];
    
    if ($muted==1) {
    
    }
    else {
        
    echo <<<_END
<form action="chat3.php" method="post">  
Send a Message:<br>
Message: <input type="text" name="chats" value="$chats">
<input type="submit" value="Submit">
</form>
    
_END;
}
}
}

// finish off the HTML for this page:
require_once "footer.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>