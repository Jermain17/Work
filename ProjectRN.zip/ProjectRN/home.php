<?php

// execute the header script:
require_once "header.php";
$chats = ""; 

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 20;

if (!isset($_SESSION['loggedInWeek12']))
{
    
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{
    
    // has the form just been submitted? Or have we arrived here by using the navigation bar?

// the session starts   
$username = $_SESSION['username'];
if(ISSET($_POST['chats']))
{
$message = $_POST['chats'];
    // user is already logged in, read all the favourite numbers and display in a table:
    
    // connect directly to our database (notice 4th argument):
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
    
    // find all favourite numbers, ordered by their last update time (descending):
    $query = "INSERT INTO chat(username, chats ) VALUES ('$username', '$message') ";    
    // this query can return data ($result is an identifier):
    $result = mysqli_query($connection, $query);
            
    // how many rows came back?:
    //$n = mysqli_num_rows($result);
        if (! $result){
            echo mysqli_error($connection);
        }
}
    // if we got some results then show them in a table:

    {
// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
    
    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/one-page-wonder.min.css" rel="stylesheet">
    
    

  </head>

  <body>

 

    <header class="masthead text-center text-white">
      <div class="masthead-content">
        <div class="container">
          <h1 class="masthead-heading mb-0">Improve your knowledge</h1>
          <h2 class="masthead-subheading mb-0">By learning HTML</h2>
          <a href="lesson1.php" class="btn btn-primary btn-xl rounded-pill mt-5">Learn More</a>
        </div>
      </div>
       
      <div class="bg-circle-1 bg-circle"></div>
      <div class="bg-circle-2 bg-circle"></div>
      <div class="bg-circle-3 bg-circle"></div>
      <div class="bg-circle-4 bg-circle"></div>
	  
    </header>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 order-lg-2">
            <div class="p-5">
            

            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="p-5">
              <h2 class="display-4">What is HTML?</h2>
              <p>HTML is a computer language that is used to design websites. With CSS, that is just the front end of the website. The colours, images etc. Is a simple computer based language.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="img/2.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6">
            <div class="p-5">
              <h2 class="display-4">Why learn HTML?</h2>
              <p>Because you will be able to increase your knowledge on how computer languages are. HTML is one of the easiest computer languages to start learning. If you are able to learn HTML to the advanced level you will be able to tackle any other computer languages!.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 order-lg-2">
            <div class="p-5">
              <img class="img-fluid rounded-circle" src="img/3.jpg" alt="">
            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="p-5">
              <h2 class="display-4">Advantages of HTML</h2>
              <p>Advantages of HTML:
1. First advantage it is widely used.
2. Every browser supports HTML language.
3. Easy to learn and use.
4. It is by default in every windows so you don't need to purchase extra software.
</p>
            </div>
          </div>
        </div>
      </div>
    </section>

 
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>




_END;
	}
}
require_once "footer.php";

?>
