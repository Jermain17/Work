<?php


// execute the header script:
require_once "header.php";

// default value we show in the form:
$posts = "";
// string to hold any validation error message:
$favourite_val = "";
// should we show the set posts number form?:
$show_set_form = false;
// message to output to user:
$message = "";
// the minimum and maximum numbers we will allow 
// between -/+ 2 billion, which our database table can comfortably hold with a BIGINT, 
// HTML5 can validate on the client-side, and should be big enough for most users :-)
$max_int = 2000000000;
$min_int = -$max_int;

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
elseif (isset($_POST['posts']))
{
	// user just tried to update their favourite number:
	
	// connect directly to our database (notice 4th argument) we need the connection for sanitisation:
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	// SANITISATION (see helper.php for the function definition)
	
	// take a copy of the value the user submitted and sanitise (clean):
	$posts = sanitise($_POST['posts'], $connection);

	// VALIDATION (see helper.php for the function definitions)
	
	// now validate the data (int must be between +/- 2 billion):
	$favourite_val = validateInt($posts, $min_int, $max_int);
	
	// concatenate all the validation results together ($errors will only be empty if ALL the data is valid):
	$errors = $favourite_val;
	
	// check that all the validation tests passed before going to the database:
	if ($errors == "")
	{	
		// read their username from the session:
		$username = $_SESSION["username"];
		
		// now write their new favourite number to our database table...
		
		// check to see if this user already had a favourite:
		$query = "SELECT value FROM favourites WHERE username='$username'"; //selects value from the favourites table
		
		// this query can return data ($result is an identifier):
		$result = mysqli_query($connection, $query);
		
		// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
		$n = mysqli_num_rows($result);
			
		// if there was a match then UPDATE their favourite number, otherwise INSERT it:
		if ($n > 0)
		{
			// we need an UPDATE (we use SYSDATE() to get the current server time):
			$query = "UPDATE favourites SET value=$posts,updated=SYSDATE(),likes=0 WHERE username='$username'";
			$result = mysqli_query($connection, $query);		
		}
		else
		{
			// we need an INSERT (leaving the update timestamp empty causes MySQL to use the current time):
			$query = "INSERT INTO favourites (username, value) VALUES ('$username', $posts)";
			$result = mysqli_query($connection, $query);	
		}

		// no data returned, we just test for true(success)/false(failure):
		if ($result) 
		{
			// show a successful update message:
			$message = "Favourite number successfully updated<br>";
		} 
		else
		{
			// show an unsuccessful update message:
			$message = "Update failed<br>";
		}
	}
	else
	{
		// validation failed, show the form again with guidance:
		$show_set_form = true;
		// show an unsuccessful update message:
		$message = "Update failed, please check the errors shown above and try again<br>";
	}
	
	// we're finished with the database, close the connection:
	mysqli_close($connection);

}
else
{
	// arrived at the page for the first time, just show the form:
	$show_set_form = true;
}

if ($show_set_form)
{
// show the form that allows users to log in
// Note we use an HTTP POST request to avoid their password appearing in the URL:
if (isset($_GET['noval']))
	{
// a version WITHOUT client-side validation so that we can test server-side validation:
echo <<<_END
<form action="set_posts.php?noval=y" method="post">
  Enter your new posts number:<br>
  <input type="text" name="posts" value="$posts"> $favourite_val
  <br>
  <input type="submit" value="Submit">
</form>	
_END;
	}
	else
	{
// a version WITH client-side validation:
echo <<<_END
<form action="set_posts.php" method="post">
  Enter your new posts :<br>
	<input name="posts" min="$min_int" max="$max_int" value="$posts" required> $favourite_val
  <br>
  <input type="submit" value="Submit">
</form>	
_END;
	}
}

// display our message to the user:
echo $message;

// finish of the HTML for this page:
require_once "footer.php";
?>