<?php

// execute the header script:
require_once "header.php";

echo "Welcome to the website to learn HTML, enjoy yourselves!.<br>";  //this message prints out in the abouts

// finish of the HTML for this page:
require_once "footer.php";

?>