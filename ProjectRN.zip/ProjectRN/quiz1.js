
function check(){

	var question1 = document.quiz.question1.value;
	var question2 = document.quiz.question2.value;
	var question3 = document.quiz.question3.value;
	var correct = 0;


if (question1 == "Tags") {
	correct++;	
}

if (question2 == "!DOCTYPE html") {
	correct++;
}

if (question3 == "Hyper Text Markup Language") {
	correct++; 
}


	document.getElementById("after_submit").style.visibility = "visible";
	document.getElementById("number_correct").innerHTML = "You got " + correct + " correct.";

	}
	
