<?php


// execute the header script:
require_once "header.php";

if (!isset($_SESSION['loggedInWeek12']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}
else
{
	// user is already logged in, read their username from the session:
	$username = $_SESSION["username"];
	
	// now delete their favourite number and membership details from the tables...
	
	// connect directly to our database (notice 4th argument):
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
	
	// 1. delete their favourite number from the favourites table:
	$query = "DELETE FROM favourites WHERE username='$username'";
	$result = mysqli_query($connection, $query);
			
	// no data returned, we just test for true(success)/false(failure):
	if ($result) 
	{
		echo "favourite number deleted<br>";
	} 
	else
	{
		echo "favourite number not deleted (there may not be one)<br>";
	}
	
	// 2. delete their membership record from the members table:
	$query = "DELETE FROM members WHERE username='$username'";
	$result = mysqli_query($connection, $query);
			
	// no data returned, we just test for true(success)/false(failure):
	if ($result) 
	{
		// account successfully deleted:
		echo "delete membership succeeded<br>";
		// destroy the session data:
		// first clear the session superglobal array:
		$_SESSION = array();
		// then the cookie that holds the session ID:
		setcookie(session_name(), "", time() - 2592000, '/');
		// then the session data on the server:
		session_destroy();

		echo "You have successfully removed your account, please <a href='sign_in.php'>click here</a><br>";
	} 
	else
	{
		echo "delete membership failed<br>";
	}
	
	// we're finished with the database, close the connection:
	mysqli_close($connection);
}

// finish off the HTML for this page:
require_once "footer.php";

?>