<?php


// database connection details:
require_once "credentials.php";

// our helper functions:
require_once "helper.php";

// start/restart the session:
session_start(); //Sessions details stored in the server

if (isset($_SESSION['loggedInWeek12']))
{
    // THIS PERSON IS LOGGED IN
    // show the logged in menu options:
    $username = $_SESSION["username"];
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    $query = "SELECT * FROM members where username ='$username'"; //this is the query that selects all the people that are in my members table
    
    $result = mysqli_query($connection, $query);
    $row= mysqli_fetch_assoc($result);
    $type = $row['type'];
    
    if ($type==1)
    {
        echo <<<_END
<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
 
<a href='about.php'>about</a> || 
<a href='show_favourite.php'>Show Favourite</a> ||
<a href='set_favourite.php'>Set Favourite</a> ||
<a href='recent_favourites.php'>Recent Favourite</a> ||
<a href='all_favourites.php'>All Favourite</a> ||
<a href='show_profile.php'>Profiles</a> ||
<a href='set_profile.php'>Set Profile</a> ||
<a href='delete_account.php'>delete user accounts</a> ||
<a href='Game.php'>Game</a> ||
<a href='chat3.php'>Chat</a> ||
<a href='delete.php'>Delete Comment</a> ||
<a href='search.php'>Find a user</a> ||
<a href='admin.php'>The moderator</a> ||
<a href='sign_out.php'>sign out ({$_SESSION['username']})</a>
<br><br>
_END;
    }
    else {

echo <<<_END
<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    </head>
<body>
 
<a href='about.php'>about</a> ||
<a href='show_favourite.php'>Your Highscore</a> ||
<a href='set_favourite.php'>Set Favourite</a> ||
<a href='recent_favourites.php'>Recent Favourite</a> ||
<a href='all_favourites.php'>All Favourite</a> ||
<a href='show_profile.php'>Profiles</a> ||
<a href='set_profile.php'>Set Profile</a> ||
<a href='delete_account.php'>delete user accounts</a> ||
<a href='Game.php'>Game</a> ||
<a href='chat3.php'>Chat</a> ||
<a href='delete.php'>Delete Comment</a> ||
<a href='search.php'>Find a user</a> ||
<a href='sign_out.php'>sign out ({$_SESSION['username']})</a>
<br><br>
_END;
    }
}

else
{
    // THIS PERSON IS NOT LOGGED IN
    // show the logged out menu options:
    
echo <<<_END
<!DOCTYPE html>
<html>
<body>
<a href='about.php'>about</a> ||
<a href='sign_up.php'>sign up</a> ||
<a href='sign_in.php'>sign in</a>
<br><br>
_END;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>