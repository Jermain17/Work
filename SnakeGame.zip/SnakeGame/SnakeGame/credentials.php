<?php
// default values for Xampp:
$dbhost  = 'localhost'; //information to connect to the database
$dbuser  = 'root';
$dbpass  = '';
$dbname  = 'SnakeGame';
?>