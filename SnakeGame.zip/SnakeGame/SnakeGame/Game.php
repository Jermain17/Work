<?php


require_once "header.php";

if (!isset($_SESSION['loggedInWeek12']))
{
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{

    // connect directly to our database (notice 4th argument):
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
        //the sessions starts
    $username = $_SESSION["username"];

    $query3 = "SELECT * FROM members where username ='$username'"; //this is the query that selects all the people that are in my members table
    $result3 = mysqli_query($connection, $query3);
    $row = mysqli_fetch_assoc($result3);
    $highscore = $row['highscore'];
    
echo <<<_END

<html>
    <head>
    

    <body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- What code do we need? -->
    <script>
    $(document).ready(function() { 
        $("body").keydown(function(event) {
            player.lastKeyPressed = event.which
            move();
        });
        make_snake();
        create_food(); 
        requestAnimationFrame(draw);
    });
    //this is my variables I am calling in this script that I am using
    var counter = 0; 
    var fps = 40;
    var cells = 25;
    var make_array=[];
    var i = 0;
    var j = 0;
    var game = "playing";
    var way = "right";
    var score=0;
    var itachi=0;

    var player = {
        x: 0,
        y: 0,
        lastKeyPressed: 0
        
    
    }
    
	//this are the functions that move the snake
    function move() {
        if ((player.lastKeyPressed == 37)&&(way!="right")) {
            way = "left";
            console.log("left");
        }
        if ((player.lastKeyPressed == 39)&&(way!="left")) {
            way = "right";
            console.log("right");
        }
        if ((player.lastKeyPressed == 40)&&(way!="up")) {
            way = "down";
            console.log("down");
        }
        if ((player.lastKeyPressed == 38)&&(way!="down")) {
            way = "up";
            console.log("up");
        }
        
        
    }

    function draw() { //makes everything move
        setTimeout(function() {
                $("#up").click(function(){
                way = "up";
    });
            
                $("#down").click(function(){
                way = "down";
    });
                $("#left").click(function(){
                way = "left";
    });
                $("#right").click(function(){
                way = "right";

    });
    
            var cvs = $("canvas").get(0);
            var ctx = cvs.getContext("2d");
            
            if(game == "playing"){

            var deltaX = player.x;
            var deltaY = player.y;
            
            console.log(player.x + "--" + player.y);    

            if(way=="right"){
                player.x++;
                console.log("going right");
            }
            else if(way=="left"){
                player.x--;
                console.log("going left");
            }
            else if(way=="up"){
                player.y--;
                console.log("going up");
            }
            else if(way=="down"){
                player.y++;
                console.log("going down");
            }
            
        
            
            checkSides(); //the sides when the snake crashes
            make_array.push({
                x:player.x,
                y: player.y
            
                });
                make_array.shift();

            ctx.clearRect(0, 0, cvs.width, cvs.height);
            ctx.fillStyle = "red"; //changes the snake colour
            ctx.fillRect(player.x * cvs.width / cells, player.y * cvs.height / cells, //draws the square
                cvs.width / cells,
                cvs.height / cells);
            for(var i = make_array.length-1; i>=0; i--) {
                ctx.fillRect(make_array[i].x * cvs.width / cells, make_array[i].y * cvs.height / cells, //draws the square
                cvs.width / cells,
                cvs.height / cells);
            }
            ctx.fillText("score: "+score,10,10);
            }else{
                
                 ctx.fillText("Game Over!",300,150);
            }
            drawFood(); //you call it from here
            checkFood();
            requestAnimationFrame(draw);

        }, 4000 / fps);
    }

    //ajax post request
    function game2()
    {
     $.ajax({
  type: "POST",
  url: 'Game.php',
     data: {itachi: score},
  success: function(data){
  console.log("success");}
  });
  
_END;
  
    if(isset($_POST['itachi']))
    {
        if (isset ($_POST['itachi']) != 0)
        {   
        $query = "INSERT INTO score ( username,score) VALUES ('$usernames[$i]', '".$_POST['itachi']."')";
        $result = mysqli_query($connection, $query);
        }
        else{}
    
    
    if ($_POST['itachi'] > $highscore)
        {   
        $query1 = "UPDATE members set highscore = '".$_POST['itachi']."' WHERE username='$username'";
        $result1 = mysqli_query($connection, $query1);
        }
        else{}
    }
    
    echo <<<_END
    }
    
    
        function make_snake(){    //this makes the snake starts
    
        var length = 2; //Length of the snake
        make_array = []; //Empty ArrayList
        for(var i = length-1; i>=0; i--)
        {
            make_array.push({
                x: 0,
                y: i        
            });
        }
        }

    function drawFood() { //draws the food
        var c = $("canvas").get(0);
        var ctx = c.getContext("2d");
        ctx.fillStyle = "blue";
        counter = counter+1;
          if ( counter < 10 )
          {
        var sasuke = new Image(); //the images that are used in the animation
        sasuke.src = 'sasuke.png';  
        ctx.drawImage(sasuke,food.x * c.width / cells, food.y* c.height / cells, c.width / cells, c.height / cells);
          }
          else if (counter < 20){
              
          
        var Rinnegan = new Image(); //the images that are used in the animation
        Rinnegan.src = 'Rinnegan.png';  
        ctx.drawImage(Rinnegan,food.x * c.width / cells, food.y* c.height / cells, c.width / cells, c.height / cells);
          }
          else  {
            if (counter >30)
            {
                counter = 1; //sets the counter back to one
            }
          
        var Sage = new Image(); //the images that are used in the animation
        Sage.src = 'Sage.png';  
        ctx.drawImage(Sage,food.x * c.width / cells, food.y* c.height / cells, c.width / cells, c.height / cells);
          }
     


    
    move();

       // ctx.fillRect(food.x * c.width / cells, food.y* c.height / cells, c.width / cells, c.height / cells);
        ctx.stroke();
    }
        function create_food()// this creates the food
    {
        food = {
            x: Math.floor((Math.random() *cells)), //puts the food in a random place
            y: Math.floor(Math.random() *cells)
        };

    }
	
    function checkSides() { //the sides crashes when you touch it with the snake
        if (player.x > 24 || player.x < 0 || player.y > 24 || player.y < 0) {
            game = "over";  //this makes the game over
            console.log("over the edge");
            game2();
        }
        
    }
    function checkFood() { //it allows you to eat the food
        if(player.x == food.x && player.y ==food.y){
            create_food();
            score++;
            make_array.push({
                x: -10,
                y: -10
                });
        }
    }
    
    
    
    
</script>

</body>

</html>
 
    </script>
    
    </head>

    
    
    <body>
<center> <!-- moves to center -->
<h1> Jermain Johnson Snake </h1>
    <  <canvas id='canvas' width='600' height='400' style="border: solid blue 5px">
        Sorry, no canvas support!
    </canvas>
    </center>
    </body>
<center>
<!--buttons that you click to move the snake -->
<input type="button" value="up" id='up'/>  <br>
<input type="button" value="left" id='left'/>
<input type="button" value="down" id='down'/>
 <input type="button" value="right" id='right'/>
 </center>
</html>
_END;
}

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>