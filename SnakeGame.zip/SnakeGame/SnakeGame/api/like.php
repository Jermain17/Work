<?php


include_once "../credentials.php";

// variable to store the data we'll send back
$response['post_id'] = "";


if ( !isset($_POST['post_id']))
{
	// set the kind of data we're sending back and an error response code:
	header("Content-Type: application/json", NULL, 400);
	// and send:
	echo json_encode($response);
	// and exit this script:
	exit;
}
else
{
	
	$post_id = $_POST['post_id'];
}

// copy the username into our response:

$response['post_id'] = $post_id;
// connect directly to our database (notice 4th argument):
$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// connection failed, return an internal server error:
if (!$connection)
{
	// set the kind of data we're sending back and an error response code:
	header("Content-Type: application/json", NULL, 500);
	// and send:
	echo json_encode($response);
	// and exit this script:
	exit;
}

// update the number of likes for this user/favourite:
$query = "UPDATE chat SET likes=likes+1 WHERE post_id='$post_id'";

// no data, just true/false:
$result = mysqli_query($connection, $query);

// no data returned, we just test for true(success)/false(failure):
if ($result) 
{
	// did we actually change a row?
	if (mysqli_affected_rows($connection) == 1)
	{
		// set the kind of data we're sending back and a success response code:
		header("Content-Type: application/json", NULL, 201);
	}
	else
	{
		// set the kind of data we're sending back and an error response code:
		header("Content-Type: application/json", NULL, 400);
	}
}
else
{
	// something went wrong (e.g., user may have just changed their number)
	// set the kind of data we're sending back and an error response code:
	header("Content-Type: application/json", NULL, 400);
}

// we're finished with the database, close the connection:
mysqli_close($connection);

// and send:
echo json_encode($response);

?>