<?php

// execute the header script:
require_once "header.php";

echo "Snake Game, Enjoy yourselves!.<br>";  //this message prints out in the abouts

// finish of the HTML for this page:
require_once "footer.php";

?>