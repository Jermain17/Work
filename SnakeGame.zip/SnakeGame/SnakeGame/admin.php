<?php


// execute the header script:
require_once "header.php";

// default value we show in the form:
$favourite = "";
// string to hold any validation error message:
$favourite_val = "";
// should we show the set favourite number form?:
$show_set_form = false;
// message to output to user:
$message = "";

$max_int = 2000000000;
$min_int = -$max_int;

if (!isset($_SESSION['loggedInWeek12']))
{
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{
    // user just tried to update their favourite number:
    
    // connect directly to our database (notice 4th argument) we need the connection for sanitisation:
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    // if the connection fails, we need to know, so allow this exit:
    if (!$connection)
    {
        die("Connection failed: " . $mysqli_connect_error);
    }
    
    if (isset ($_POST['muteuser'])){
        
    
    //mute
    $mute = sanitise($_POST['muteuser'], $connection);
    $query = "UPDATE members SET muted = '1'  WHERE username='$mute';";
    $result = mysqli_query($connection, $query);
    }   
    if (isset ($_POST['unmuteuser'])){
    //unmute        
    $unmute = sanitise($_POST['unmuteuser'], $connection);
    $query1 = "UPDATE members SET muted= '0'  WHERE username='$unmute';";
    $result1 = mysqli_query($connection, $query1);
    }
    // SANITISATION (see helper.php for the function definition)
    
    // take a copy of the value the user submitted and sanitise (clean):
    

    // VALIDATION (see helper.php for the function definitions)
    
    // now validate the data (int must be between +/- 2 billion):
    $favourite_val = validateInt($favourite, $min_int, $max_int);
    
    // concatenate all the validation results together ($errors will only be empty if ALL the data is valid):
    $errors = $favourite_val;
    
    // check that all the validation tests passed before going to the database:
        
        // read their username from the session:
        $username = $_SESSION["username"];
        
        // now write their new favourite number to our database table...
        
        // check to see if this user already had a favourite:

        // how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
    
            
        // if there was a match then UPDATE their favourite number, otherwise INSERT it:
     
    
// a version WITH client-side validation:
echo <<<_END
<form action="admin.php" method="post">
Mute:<br>
<input type="text" name="muteuser" value="">
<br>
  <input type="submit" value="Submit">
</form> 
_END;
    
echo <<<_END
<form action="admin.php" method="post">
Unmute:<br>
<input type="text" name="unmuteuser" value="">
<br>
 <input type="submit" value="Submit">
</form> 
_END;
    
    
$querys = "SELECT * FROM members;";   
                     
echo <<<_END

<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.load("visualization", "1", {packages:["corechart"]});
      // Set a callback to run when the Google Visualization API is loaded.
      google.setOnLoadCallback(drawChart);

      // Callback that creates and populates a data table,
      // instantiates the pie chart, passes in the data and
      // draws it.
      function drawChart() {

        // Create the data table.
        var data = google.visualization.arrayToDataTable([
		
        ['username','highscore'],
_END;
           
                $results = mysqli_query($connection, $querys);
                
                while($rows = mysqli_fetch_array($results))
                {
                        
                        
                        
                        // reads the values
 
                        echo "['".$rows['username']."',".$rows['highscore']."],";
          
                }
              
echo <<<_END
                ]);
        // Set chart options
        var options = {title: 'Scores of users'};

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('chart'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <!--Div that will hold the pie chart-->
    <div id="chart" style = "width:400px; height:400px;"></div>
  </body>
</html>

_END;
  
}

// display our message to the user:
echo $message;
   mysqli_close($connection);
// finish of the HTML for this page:
require_once "footer.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>