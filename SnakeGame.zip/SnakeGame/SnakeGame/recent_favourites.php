<?php


// execute the header script:
require_once "header.php";

// how many milliseconds to wait between updates:
$milliseconds = 5000;
// how many recent favourites to display:
$nrows = 5;

if (!isset($_SESSION['loggedInWeek12']))
{
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
}
else
{

// CSS to make the table clearly visible, and jQuery to control updates:
echo <<<_END
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>   
    
<style>
    table, th, td {border: 1px solid black; align: center;}
</style>
<table id='favourites'> //table name
<tr><th>User</th><th>Favourites</th><th>Updated</th><th>Likes</th></tr>
</table>

<script>
$(document).ready(function()
{   
    // as soon as the page is ready, start checking for updates:
    checkForFavourites();
});

function checkForFavourites(){
        
    $.getJSON('api/recent.php', {number: $nrows})
        .done(function(data) {
            // debug message to help during development:
            console.log('request successful');
            
            // remove the old table rows:
            $('.result').remove();
            
            // loop through what we got and add it to the table (data is already a JavaScript object thanks to getJSON()):
            $.each(data, function(index, value) {
                $('#favourites').append("<tr class='result'><td>" + value.username + "</td><td>" + value.value + "</td><td>" + value.updated + "</td><td>" + value.likes + "</td></tr>");
            });
        })
        .fail(function(jqXHR) {
            // debug message to help during development:
            console.log('request returned failure, HTTP status code ' + jqXHR.status);
        })
        .always(function() {
            // debug message to help during development:
            console.log('request completed');
            // call this function again after a brief pause:
            setTimeout(checkForFavourites, $milliseconds);
        });
}

</script>
_END;
        
}

// finish off the HTML for this page:
require_once "footer.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
</body>
</html>